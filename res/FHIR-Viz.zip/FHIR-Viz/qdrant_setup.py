
from qdrant_client import QdrantClient
from qdrant_client.models import VectorParams, Distance, PointStruct
import json
import uuid
from vertexai.preview.language_models import TextEmbeddingModel

# Initialize Gemini embedding model and Qdrant client
model = TextEmbeddingModel.from_pretrained("")
qdrant = QdrantClient("http://localhost", port=7000)
COLLECTION_NAME = ""
LIMIT = 0  # Requests per minute limit


delay = 60/LIMIT  # Calculate delay based on requests per minute limit

# -------------------- Step 1: Create Collection -------------------- #
def create_qdrant_collection():
    collections = qdrant.get_collections().collections
    if COLLECTION_NAME not in [c.name for c in collections]:
        qdrant.create_collection(
            collection_name=COLLECTION_NAME,
            vectors_config=VectorParams(
                size=3072,
                distance=Distance.COSINE
            )
        )
        print(f"✅ Collection '{COLLECTION_NAME}' created.")
    else:
        print(f"ℹ️ Collection '{COLLECTION_NAME}' already exists.")

# -------------------- Step 2a: Chunk properties_values.json -------------------- #
def chunk_properties(path, max_distinct=5):
    with open(path, "r", encoding="utf-8-sig") as f:
        data = json.load(f)

    chunks = []
    for entry in data:
        label = entry.get("label", "UnknownLabel")
        prop = entry.get("property", "UnknownProperty")
        values = entry.get("distinctValues", [])
        limited_values = values[:max_distinct]

        chunk_text = (
            f"LABEL: {label}\n"
            f"PROPERTY: {prop}\n"
            f"DISTINCT_VALUES (up to {max_distinct}):\n"
            f"{json.dumps(limited_values, indent=2)}"
        )
        chunks.append(chunk_text)

    return chunks

# -------------------- Step 2b: Chunk schema.json -------------------- #
def chunk_schema(path):
    with open(path, "r", encoding="utf-8-sig") as f:
        data = json.load(f)

    chunks = []
    for section in data:
        if "nodes" in section:
            for node in section["nodes"]:
                chunks.append(f"NODE:\n{json.dumps(node, indent=2)}")
        if "relationships" in section:
            for rel in section["relationships"]:
                chunks.append(f"RELATIONSHIP:\n{json.dumps(rel, indent=2)}")

    return chunks

# -------------------- Step 3: Embed a single chunk -------------------- #
def embed_text(text):
    embeddings = model.get_embeddings([text])
    return embeddings[0].values

# -------------------- Step 4: Upload all chunks -------------------- #
import time  # Add this import at the top

def upload_chunks_to_qdrant(chunks):
    points = []

    for i, chunk in enumerate(chunks):
        vector = embed_text(chunk)

        points.append(PointStruct(
            id=str(uuid.uuid4()),
            vector=vector,
            payload={"text": chunk}
        ))

        print(f"✅ Embedded chunk {i+1}/{len(chunks)}")

        # Add delay to stay within 5 requests per minute (1 request every 12 seconds)
        if i < len(chunks) - 1: # Avoid delay after last chunk
            time.sleep(delay)

    qdrant.upsert(collection_name=COLLECTION_NAME, points=points)
    print(f"✅ Uploaded {len(points)} schema chunks to Qdrant in collection '{COLLECTION_NAME}'.")

# -------------------- MAIN -------------------- #
if __name__ == "__main__":
    create_qdrant_collection()

    # Provide full paths
    properties_path = ""
    schema_path = ""

    # Get all chunks
    property_chunks = chunk_properties(properties_path)
    schema_chunks = chunk_schema(schema_path)

    # Combine and upload
    all_chunks = property_chunks + schema_chunks
    upload_chunks_to_qdrant(all_chunks)








# # from qdrant_client import QdrantClient
# # from qdrant_client.http.models import Distance, VectorParams

# # # Connect to Qdrant
# # client = QdrantClient(host="localhost", port=7000)

# # # Collection name
# # collection_name = "schema"

# # # Delete if exists
# # if client.collection_exists(collection_name=collection_name):
# #     client.delete_collection(collection_name=collection_name)



# # client.create_collection(
# #     collection_name="schema",
# #     vectors_config=VectorParams(size=768, distance=Distance.COSINE)
# # )






# from qdrant_client import QdrantClient
# qdrant_schema = QdrantClient(host="localhost", port=7000)
# try:
#     collections = qdrant_schema.get_collections()
#     print("Successfully connected to Qdrant. Collections:", collections)
# except Exception as e:
#     print(f"Failed to connect to Qdrant: {e}")
