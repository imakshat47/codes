import os
import json
import uuid
from typing import TypedDict, Optional, List, Dict, Any
from neo4j import GraphDatabase
from google.cloud import aiplatform
from vertexai.generative_models import GenerativeModel
from vertexai.preview.language_models import TextEmbeddingModel
from qdrant_client import QdrantClient
from qdrant_client.http.models import SearchRequest
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import re

# --- Configuration ---
NEO4J_URI = ""

NEO4J_USER = ""
NEO4J_PASSWORD = ""
project_id = ""
location = ""


neo4j_driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))


# --- Initialize Vertex AI SDK ---
aiplatform.init(project=project_id, location=location)

# --- Qdrant Client for schema retrieval ---
qdrant_schema = QdrantClient(host="localhost", port=7000)

# --- Step 1: Embed a query using Gemini embedding model ---
def embed_query(text):
    model = TextEmbeddingModel.from_pretrained("gemini-embedding-001")
    embeddings = model.get_embeddings([text])
    return embeddings[0].values

# --- Step 2: Retrieve top schema chunks from Qdrant ---
def retrieve_top_schema_chunks(query, top_k=15):
    embedding = embed_query(query)
    results = qdrant_schema.search(
        collection_name="schema",
        query_vector=embedding,
        limit=top_k
    )
    return [hit.payload["text"] for hit in results]

# --- Step 3: Build prompt for the Gemini model ---
def build_prompt(user_query, schema_str):
    context = f"""You're a Cypher expert for a FHIR-based medical knowledge graph built from the Synthea dataset in Neo4j.

Schema:
{schema_str}

User Question: "{user_query}"

Return a Cypher query that answers the question.
No explanation, just the Cypher code."""
    return context


def execute_cypher(driver, cypher_query: str) -> List[dict]:
    with driver.session() as session:
        result = session.run(cypher_query)
        return [dict(record) for record in result]
    

import re

def check_query(user_query: str, cypher_query: str) -> str:
    model = GenerativeModel("gemini-2.5-flash-preview-05-20")

    while True:
        try:
            # Remove leading and trailing code block markers if present
            cypher_query = cypher_query.strip().removeprefix("```cypher").removesuffix("```").strip()

            # Try executing the query
            execute_cypher(neo4j_driver, cypher_query)
            return cypher_query  # Query is valid, return it

        except Exception as e:
            print(f"Query error: {str(e)}")

            # Ask the model to correct the query
            prompt = f"""The following Cypher query generated an error for the given user query on the Synthea dataset:\n\nUser Query:\n{user_query}\n\nCypher Query:\n{cypher_query}\n\nError:\n{str(e)}\n\nPlease fix the query and return only the corrected Cypher code without explanation."""
            response = model.generate_content(prompt)

            # Strip code fences from model response
            cypher_query = response.text.strip()





def run_retrieval_process(user_query) -> tuple[str, str]:
    try:
        model = GenerativeModel("gemini-2.5-flash-preview-05-20")   
        schema_chunks = retrieve_top_schema_chunks(user_query, top_k=25)
        schema_context = "\n---\n".join(schema_chunks)
        prompt = build_prompt(user_query, schema_context)
        response = model.generate_content(prompt)
        cypher_query = response.text.strip()

        check_query(user_query,cypher_query)
        print("\n--- GENERATED CYPHER QUERY ---")
        print(cypher_query)
        approved = input("Approve this Cypher query? (y/n): ").strip().lower()

        if approved == "y":
            final = input("Edit the final Cypher (or press Enter to keep): ").strip()
            if final:
                cypher_query = final

            kg_data = execute_cypher(neo4j_driver, cypher_query)

            if kg_data:
                return user_query, json.dumps(kg_data, indent=2)
            else:
                return user_query, "No data found for the given query."
        else:
            return user_query, "Query was not approved by the user."

    except Exception as e:
        return user_query, f"Error: {str(e)}"


def run_coding_process(user_query):
    query, kg_data = run_retrieval_process(user_query)
    if "Error" in kg_data or "No data" in kg_data or "not approved" in kg_data:
        return kg_data

    try:
        model = GenerativeModel("gemini-2.5-flash-preview-05-20")
        prompt = f"""You're a Python expert in medical data visualization.

Given this Neo4j query result (FHIR data from Synthea):

{query}
{kg_data}

Generate a Python script using pandas and matplotlib/seaborn to visualize it.

- Output only valid Python code.
- No explanations or markdown."""

        response = model.generate_content(prompt)
        python_code = response.text.strip()

        print("\n--- GENERATED PYTHON CODE ---")
        print(python_code)
        approved = input("Approve this Python Code? (y/n): ").strip().lower()

        if approved == "y":
            final = input("Enter the final Python code (or press Enter to keep): ").strip()
            if final:
                python_code = final
            return python_code
        else:
            return "Code not approved by the user."

    except Exception as e:
        return f"Error generating Python code: {str(e)}"


def run_executor_node(user_query):
    code = run_coding_process(user_query)
    if not code or "Error" in code or "not approved" in code:
        return code

    try:
        exec(code, {"pd": pd, "plt": plt, "sns": sns})

        if os.path.exists("chart.png"):
            with open("chart.png", "rb") as f:
                chart_data = f.read()
            return chart_data
        else:
            return "No chart generated. Please check the Python code."

    except Exception as e:
        return f"Error executing Python code: {str(e)}"



# Test it
result = run_executor_node(" Patients with at Least One Condition: Distribution by Age Group")
if isinstance(result, bytes):
    with open("output_chart.png", "wb") as f:
        f.write(result)
    print("Chart saved as output_chart.png")
else:
    print(result)
