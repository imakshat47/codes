 
1. To start the Victim process:
 victim/run

2. To start atatcker process: 
attacker/on Secret.txt